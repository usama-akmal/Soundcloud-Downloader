﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Soundcloud_Downloader
{
    public partial class SoundcloudDownloader : Form
    {
        public SoundcloudDownloader()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            splitC.Panel2.Enabled = false;
            urlCheck.Checked = true;
        }

        private void urlCheck_CheckedChanged(object sender, EventArgs e)
        {
            if (urlCheck.Checked)
            {
                splitC.Panel2.Enabled = false;
                splitC.Panel1.Enabled = true;
            }
        }

        private void longCheck_CheckedChanged(object sender, EventArgs e)
        {
            if (longCheck.Checked)
            {
                splitC.Panel1.Enabled = false;
                splitC.Panel2.Enabled = true;
            }
        }

        private void download_Click(object sender, EventArgs e)
        {
            if (urlCheck.Checked)
            {
                if (string.IsNullOrEmpty(url.Text))
                {
                    MessageBox.Show("You cant leave url box empty :P");
                }
                else
                {
                    //Progress Bar Codeeeee
                    int i;

                    progressBar1.Minimum = 0;
                    progressBar1.Maximum = 200;

                    for (i = 0; i <= 200; i++)
                    {
                        progressBar1.Value = i;
                    }
                    ///Progress Bar code end
                    string[] address = url.Text.Split('/');
                    string username = address[address.Length - 2];
                    string songname = address[address.Length - 1];
                    string final = "http://sc-downloader.com/download/" + username + "/" + songname + ".mp3";
                    System.Diagnostics.Process.Start(final);
                    progressBar1.Value = 0;
                }
            }
            else if (longCheck.Checked)
            {
                if (string.IsNullOrEmpty(this.username.Text) && string.IsNullOrEmpty(this.songname.Text))
                {
                    MessageBox.Show("You can not leave username and songname box empty :P 3:)");
                }
                else
                {
                    //Progress Bar Codeeeee
                    int i;

                    progressBar1.Minimum = 0;
                    progressBar1.Maximum = 200;

                    for (i = 0; i <= 200; i++)
                    {
                        progressBar1.Value = i;
                    }
                    ///Progress Bar code end
                    string username = this.username.Text;
                    string songname = this.songname.Text;
                    string final = "http://sc-downloader.com/download/" + username + "/" + songname + ".mp3";
                    System.Diagnostics.Process.Start(final);
                    progressBar1.Value = 0;
                }
            }
        }

        private void howtouse_Click(object sender, EventArgs e)
        {
            HowToUse f = new HowToUse();
            f.Show();
            this.Hide();
        }

        private void about_Click(object sender, EventArgs e)
        {
            About f = new About();
            f.Show();
            this.Hide();
        }
    }
}
